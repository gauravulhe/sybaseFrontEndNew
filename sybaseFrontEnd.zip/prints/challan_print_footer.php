		<div class="footer">
			<table width="100%">
				<tr><td><hr></td></tr>
			</table>
			<table>
				<tr>
					<td>
						<p style="font-size:9px;">
							Certified that particulars given above are true and correct and the amount indicated represent the price actually charged & that there is flow of additional consideration directly or indirectly from the buyer. <b>OR</b><br>
							Certified that particulars given above are true and correct and the amount indicated is provisional as additional consideration will be received from the buyer on account of fluctuations in price in future.
						</p>
					</td>
				</tr>
			</table>			
		</div>
		<div class="clear"></div>